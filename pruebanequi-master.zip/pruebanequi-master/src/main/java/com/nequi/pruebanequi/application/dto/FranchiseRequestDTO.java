package com.nequi.pruebanequi.application.dto;

public record FranchiseRequestDTO(String name) {
}
