package com.nequi.pruebanequi.application.dto;

public record ProductRequestDTO(String name, int stock, Integer branch) {}

