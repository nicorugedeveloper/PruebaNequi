package com.nequi.pruebanequi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebanequiApplication {

    public static void main(String[] args) {
        SpringApplication.run(PruebanequiApplication.class, args);
    }

}
