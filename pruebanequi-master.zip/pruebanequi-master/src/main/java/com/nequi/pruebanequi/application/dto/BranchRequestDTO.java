package com.nequi.pruebanequi.application.dto;
public record BranchRequestDTO(String name) {
}
